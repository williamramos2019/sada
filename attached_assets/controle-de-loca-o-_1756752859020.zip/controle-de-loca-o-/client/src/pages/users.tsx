
import { useState } from 'react';
import { Plus, Edit, Trash2, Eye, EyeOff, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RequirePermission } from '@/components/protected-route';
import { useToast } from '@/hooks/use-toast';

const roles = [
  { value: 'admin', label: 'Administrador', color: 'bg-destructive' },
  { value: 'manager', label: 'Gerente', color: 'bg-warning' },
  { value: 'operator', label: 'Operador', color: 'bg-primary' },
];

const worksites = [
  'Obra Norte - Shopping Center',
  'Obra Sul - Residencial Alto Padrão', 
  'Obra Leste - Complexo Industrial',
  'Obra Oeste - Centro Comercial',
  'Depósito Central'
];

// Mock data for users
const mockUsers = [
  {
    id: '1',
    username: 'admin',
    email: 'admin@obrastock.com',
    role: 'admin',
    worksite: 'Depósito Central',
    isActive: true,
    lastLogin: '2024-01-20T10:30:00',
    createdAt: '2024-01-01T08:00:00',
  },
  {
    id: '2',
    username: 'joao.silva',
    email: 'joao.silva@obrastock.com',
    role: 'manager',
    worksite: 'Obra Norte - Shopping Center',
    isActive: true,
    lastLogin: '2024-01-19T16:45:00',
    createdAt: '2024-01-05T09:15:00',
  },
  {
    id: '3',
    username: 'maria.santos',
    email: 'maria.santos@obrastock.com',
    role: 'operator',
    worksite: 'Obra Sul - Residencial Alto Padrão',
    isActive: true,
    lastLogin: '2024-01-18T14:20:00',
    createdAt: '2024-01-10T11:30:00',
  },
  {
    id: '4',
    username: 'carlos.oliveira',
    email: 'carlos.oliveira@obrastock.com',
    role: 'operator',
    worksite: 'Obra Leste - Complexo Industrial',
    isActive: false,
    lastLogin: '2024-01-15T09:10:00',
    createdAt: '2024-01-12T14:45:00',
  },
];

export default function Users() {
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const { toast } = useToast();

  const handleEquipmentControl = () => {
    toast({
      title: "Em Desenvolvimento",
      description: "O controle de equipamentos locados será implementado em breve.",
    });
  };

  const handleNewUser = () => {
    toast({
      title: 'Novo Usuário',
      description: 'Funcionalidade em desenvolvimento',
    });
  };

  const handleEditUser = (userId: string) => {
    toast({
      title: 'Editar Usuário',
      description: `Editando usuário ${userId}`,
    });
  };

  const handleDeleteUser = (userId: string) => {
    toast({
      title: 'Excluir Usuário',
      description: `Excluindo usuário ${userId}`,
      variant: 'destructive',
    });
  };

  const handleToggleStatus = (userId: string) => {
    toast({
      title: 'Status do Usuário',
      description: `Alterando status do usuário ${userId}`,
    });
  };

  const getRoleBadge = (role: string) => {
    const roleObj = roles.find(r => r.value === role);
    return (
      <Badge className={roleObj?.color} data-testid={`role-badge-${role}`}>
        {roleObj?.label || role}
      </Badge>
    );
  };

  const filteredUsers = mockUsers.filter(user => {
    const matchesSearch = user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = roleFilter === 'all' || user.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  return (
    <RequirePermission permission="manage_users">
      <div className="p-4 space-y-6" data-testid="users-view">
        {/* Header */}
        <div className="flex flex-col space-y-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-foreground" data-testid="page-title">
              Gerenciamento de Usuários
            </h1>
            <Button 
              onClick={handleNewUser}
              className="flex items-center space-x-2"
              data-testid="button-add-user"
            >
              <Plus className="w-4 h-4" />
              <span>Novo Usuário</span>
            </Button>
          </div>

          {/* Admin Controls Section */}
          <div className="bg-card border border-border rounded-lg p-4">
            <h2 className="text-lg font-semibold mb-4 text-foreground">
              Controles Administrativos
            </h2>
            <div className="flex flex-col space-y-3">
              <Button
                variant="outline"
                className="flex items-center justify-start space-x-3 w-full p-4 h-auto"
                onClick={handleEquipmentControl}
                data-testid="button-equipment-control"
              >
                <div className="w-10 h-10 bg-primary/10 rounded-md flex items-center justify-center">
                  <Settings className="w-5 h-5 text-primary" />
                </div>
                <div className="text-left">
                  <p className="font-medium">Controle de Equipamentos Locados</p>
                  <p className="text-sm text-muted-foreground">
                    Gerenciar e monitorar equipamentos em locação
                  </p>
                </div>
              </Button>
            </div>
          </div>

          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
            <Input
              placeholder="Buscar usuários..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1"
              data-testid="input-search-users"
            />
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger className="w-full sm:w-48" data-testid="select-role-filter">
                <SelectValue placeholder="Filtrar por cargo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os cargos</SelectItem>
                {roles.map((role) => (
                  <SelectItem key={role.value} value={role.value}>
                    {role.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Users Table */}
        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-secondary/50">
                <tr>
                  <th className="text-left p-4 font-medium text-foreground">Usuário</th>
                  <th className="text-left p-4 font-medium text-foreground">Função</th>
                  <th className="text-left p-4 font-medium text-foreground">Obra</th>
                  <th className="text-left p-4 font-medium text-foreground">Status</th>
                  <th className="text-left p-4 font-medium text-foreground">Último Login</th>
                  <th className="text-left p-4 font-medium text-foreground">Ações</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center p-8 text-muted-foreground" data-testid="text-no-users">
                      Nenhum usuário encontrado
                    </td>
                  </tr>
                ) : (
                  filteredUsers.map((user) => (
                    <tr key={user.id} className="border-t border-border" data-testid={`user-row-${user.id}`}>
                      <td className="p-4">
                        <div>
                          <p className="font-medium text-foreground" data-testid={`user-username-${user.id}`}>
                            {user.username}
                          </p>
                          <p className="text-sm text-muted-foreground" data-testid={`user-email-${user.id}`}>
                            {user.email}
                          </p>
                        </div>
                      </td>
                      <td className="p-4">
                        {getRoleBadge(user.role)}
                      </td>
                      <td className="p-4">
                        <span className="text-sm text-foreground" data-testid={`user-worksite-${user.id}`}>
                          {user.worksite}
                        </span>
                      </td>
                      <td className="p-4">
                        <Badge 
                          variant={user.isActive ? "default" : "secondary"}
                          data-testid={`user-status-${user.id}`}
                        >
                          {user.isActive ? 'Ativo' : 'Inativo'}
                        </Badge>
                      </td>
                      <td className="p-4">
                        <span className="text-sm text-muted-foreground" data-testid={`user-last-login-${user.id}`}>
                          {new Date(user.lastLogin).toLocaleDateString('pt-BR')}
                        </span>
                      </td>
                      <td className="p-4">
                        <RequirePermission permission="manage_users">
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEditUser(user.id)}
                              data-testid={`button-edit-${user.id}`}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleToggleStatus(user.id)}
                              data-testid={`button-toggle-${user.id}`}
                            >
                              {user.isActive ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleDeleteUser(user.id)}
                              data-testid={`button-delete-${user.id}`}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </RequirePermission>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </RequirePermission>
  );
}
